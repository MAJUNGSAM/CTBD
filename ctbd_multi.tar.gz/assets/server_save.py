import os
import json
import socketio
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

# 1. Socket.IO 서버 설정 (CORS 허용으로 모든 곳에서 접속 가능하게)
sio = socketio.AsyncServer(async_mode='asgi', cors_allowed_origins='*')
app_combined = FastAPI()
app_combined.mount("/", socketio.ASGIApp(sio))

# 저장할 파일 경로
SAVE_FILE = "world_save.json"

# 서버 데이터
players = {}
world_data = {"blocks": []}

# --- 데이터 저장/로드 함수 ---
def load_data():
    if os.path.exists(SAVE_FILE):
        try:
            with open(SAVE_FILE, "r") as f:
                return json.load(f)
        except:
            return {"blocks": []}
    return {"blocks": []}

def save_data():
    with open(SAVE_FILE, "w") as f:
        json.dump(world_data, f)

# 서버 시작 시 데이터 로드
world_data = load_data()

# --- 소켓 이벤트 ---
@sio.event
async def connect(sid, environ):
    print(f"플레이어 접속: {sid}")
    # 접속한 플레이어에게 현재 월드 상태 전송
    await sio.emit("update_world", world_data, to=sid)

@sio.event
async def disconnect(sid):
    if sid in players:
        del players[sid]
    print(f"플레이어 이탈: {sid}")
    await sio.emit("player_update", players)

@sio.event
async def move(sid, data):
    players[sid] = data # 플레이어 위치 업데이트
    await sio.emit("player_update", players)

@sio.event
async def place_block(sid, data):
    # 새로운 블록 추가
    world_data["blocks"].append(data)
    save_data() # 파일에 저장
    # 모든 플레이어에게 업데이트된 월드 전송
    await sio.emit("update_world", world_data)

# --- 서버 실행 설정 (Render용) ---
if __name__ == "__main__":
    import uvicorn
    # Render는 PORT 환경 변수를 사용합니다. 없으면 기본값 10000 사용.
    port = int(os.environ.get("PORT", 10000))
    uvicorn.run(app_combined, host="0.0.0.0", port=port)
