import pygame
import asyncio
import socketio

# 1. 서버 접속 설정 (여기에 본인의 Render 주소를 넣으세요!)
# 주의: 주소 끝에 / 를 붙이지 마세요.
RENDER_SERVER_URL = "https://ctbd-majunksam.onrender.com" 

sio = socketio.AsyncClient()
players = {} # 접속한 플레이어들 정보 저장
blocks = []  # 서버에서 받아온 블록들 저장

# --- 소켓 이벤트 핸들러 ---
@sio.event
async def connect():
    print("서버 연결 성공!")

@sio.event
async def update_world(data):
    global blocks
    blocks = data.get("blocks", [])

@sio.event
async def player_update(data):
    global players
    players = data # 다른 플레이어 위치 업데이트

async def main():
    pygame.init()
    screen = pygame.display.set_mode((800, 600))
    clock = pygame.time.Clock()
    
    # 플레이어 설정
    my_id = None
    player_pos = [400, 300]
    
    # 2. 서버 연결 시도
    try:
        await sio.connect(RENDER_SERVER_URL)
        my_id = sio.sid
    except Exception as e:
        print(f"서버 접속 불가 (싱글 모드): {e}")

    running = True
    while running:
        screen.fill((135, 206, 235)) # 하늘색 배경
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            
            # 마우스 클릭 시 블록 설치 (서버로 전송)
            if event.type == pygame.MOUSEBUTTONDOWN:
                mx, my = pygame.mouse.get_pos()
                new_block = {"x": mx // 40 * 40, "y": my // 40 * 40, "color": (139, 69, 19)}
                if sio.connected:
                    await sio.emit("place_block", new_block)

        # 키보드 이동
        keys = pygame.key.get_pressed()
        moved = False
        if keys[pygame.K_LEFT]: player_pos[0] -= 5; moved = True
        if keys[pygame.K_RIGHT]: player_pos[0] += 5; moved = True
        if keys[pygame.K_UP]: player_pos[1] -= 5; moved = True
        if keys[pygame.K_DOWN]: player_pos[1] += 5; moved = True

        # 내 위치 서버에 전송
        if moved and sio.connected:
            await sio.emit("move", {"x": player_pos[0], "y": player_pos[1]})

        # 블록 그리기
        for b in blocks:
            pygame.draw.rect(screen, b["color"], (b["x"], b["y"], 40, 40))

        # 다른 플레이어들 그리기
        for pid, pos in players.items():
            color = (255, 0, 0) if pid == my_id else (0, 0, 255)
            pygame.draw.circle(screen, color, (int(pos["x"]), int(pos["y"])), 15)

        pygame.display.flip()
        await asyncio.sleep(0) # pygbag 필수 코드
        clock.tick(60)

    if sio.connected:
        await sio.disconnect()
    pygame.quit()

# pygbag 실행 구조
asyncio.run(main())
